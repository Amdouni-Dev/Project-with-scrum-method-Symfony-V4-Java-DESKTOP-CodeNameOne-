package edu.esprit.controller;

import edu.esprit.DAO.GroupDAO;
import edu.esprit.entities.Group;
import edu.esprit.lib.controller.MasterDetailCrudController;

public class GroupController extends MasterDetailCrudController<Group, GroupDAO> {

}
