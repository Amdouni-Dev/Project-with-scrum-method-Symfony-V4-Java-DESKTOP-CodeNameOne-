package edu.esprit.controller;

import edu.esprit.DAO.UserDAO;
import edu.esprit.entities.User;
import edu.esprit.lib.controller.MasterDetailCrudController;

public class UserController extends MasterDetailCrudController<User, UserDAO> {

}
