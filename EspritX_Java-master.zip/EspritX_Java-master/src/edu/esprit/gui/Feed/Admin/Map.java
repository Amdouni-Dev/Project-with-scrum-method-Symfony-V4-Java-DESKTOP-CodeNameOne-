package edu.esprit.gui.Feed.Admin;

public class Map {


}
