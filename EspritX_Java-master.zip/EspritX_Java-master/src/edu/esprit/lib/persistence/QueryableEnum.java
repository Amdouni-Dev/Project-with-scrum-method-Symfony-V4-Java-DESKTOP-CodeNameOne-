package edu.esprit.lib.persistence;

public interface QueryableEnum<T> {
    T getValue();
}
