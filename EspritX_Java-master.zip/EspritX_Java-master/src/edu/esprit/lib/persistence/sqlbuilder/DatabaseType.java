package edu.esprit.lib.persistence.sqlbuilder;

public enum DatabaseType {
	MYSQL
}
