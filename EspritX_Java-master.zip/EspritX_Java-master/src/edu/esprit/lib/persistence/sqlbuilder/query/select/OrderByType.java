package edu.esprit.lib.persistence.sqlbuilder.query.select;

public enum OrderByType {
	ASC,
	DESC
}
