<h1>"# espritx"</h1> 
<h5>Bundl/lib<h5>
<p style="color:green" >composer require friendsofsymfony/ckeditor-bundle</p>
  <p style="color:blue">axios</p>
<p style="color:green" >composer require mercuryseries/flashy-bundle</p>
<p style="color:green" >composer require easycorp/easyadmin-bundle</p>


todo:  
caching everywhere (redis)! queries, sessions, expression language ast
