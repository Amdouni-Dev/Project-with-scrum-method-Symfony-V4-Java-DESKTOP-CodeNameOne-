$((function(){"use strict";var e=$(".auth-login-form");e.length&&e.validate({rules:{"login-email":{required:!0,email:!0},"login-password":{required:!0}}})}));
