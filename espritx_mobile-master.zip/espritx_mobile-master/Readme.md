https://github.com/codenameone/cn1-codescan  
https://github.com/shannah/cn1-filechooser   
https://github.com/codenameone/FingerprintScanner   
https://github.com/rwanghk/QRMaker  
https://github.com/littlemonkeyltd/QRScanner  
**All guis must extends FORMBASE. Thank u**
