package ca.weblite.codename1.json;


/**
 *  A simple StringBuilder-based implementation of StringWriter
 */
public class StringWriter extends java.io.Writer {

	public StringWriter() {
	}

	public StringWriter(int initialSize) {
	}

	public void write(char[] cbuf, int off, int len) {
	}

	public void write(String str) {
	}

	public void write(String str, int off, int len) {
	}

	public void flush() {
	}

	public void close() {
	}
}
