/**
 *  This package contains {@link Attribute} classes for use in UI descriptors.
 *  
 */
package com.codename1.rad.attributes;


/**
 * 
 *  @author shannah
 */
public class PropertyImageRendererAttribute extends com.codename1.rad.models.Attribute {

	public PropertyImageRendererAttribute(com.codename1.rad.ui.image.PropertyImageRenderer value) {
	}
}
