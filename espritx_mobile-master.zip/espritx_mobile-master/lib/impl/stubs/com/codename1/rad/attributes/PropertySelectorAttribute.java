/**
 *  This package contains {@link Attribute} classes for use in UI descriptors.
 *  
 */
package com.codename1.rad.attributes;


/**
 * 
 *  @author shannah
 */
public class PropertySelectorAttribute extends com.codename1.rad.models.Attribute {

	public PropertySelectorAttribute(com.codename1.rad.models.PropertySelectorProvider value) {
	}

	@java.lang.Override
	public com.codename1.rad.models.PropertySelectorProvider getValue() {
	}

	public com.codename1.rad.models.PropertySelector getValue(com.codename1.rad.models.Entity root) {
	}
}
