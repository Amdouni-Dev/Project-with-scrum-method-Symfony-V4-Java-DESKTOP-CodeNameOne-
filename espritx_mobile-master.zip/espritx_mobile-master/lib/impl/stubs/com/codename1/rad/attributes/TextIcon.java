/**
 *  This package contains {@link Attribute} classes for use in UI descriptors.
 *  
 */
package com.codename1.rad.attributes;


/**
 * 
 *  @author shannah
 */
public class TextIcon extends com.codename1.rad.models.Attribute {

	public TextIcon(String text) {
	}

	public TextIcon(String text, com.codename1.rad.models.StringProvider provider) {
	}

	public String getValue(com.codename1.rad.models.Entity context) {
	}
}
