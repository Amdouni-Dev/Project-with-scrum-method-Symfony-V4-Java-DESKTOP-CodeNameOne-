/**
 *  This package contains controllers for CodeRAD applications.
 *  
 */
package com.codename1.rad.controllers;


/**
 * 
 *  @author shannah
 */
public class FieldEditorFormController extends FormController {

	public FieldEditorFormController(Controller parent, com.codename1.rad.models.Entity entity, com.codename1.rad.nodes.FieldNode fld) {
	}
}
