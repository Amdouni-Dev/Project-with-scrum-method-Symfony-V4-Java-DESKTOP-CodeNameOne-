/**
 *  This package contains property views, which are used to bind UI components with model properties.
 */
package com.codename1.rad.propertyviews;


/**
 * 
 *  @author shannah
 */
public class ImageContainerPropertyView extends com.codename1.rad.ui.PropertyView {

	public ImageContainerPropertyView(com.codename1.rad.ui.image.ImageContainer imgCnt, com.codename1.rad.models.Entity entity, com.codename1.rad.nodes.FieldNode node) {
	}

	@java.lang.Override
	protected void bindImpl() {
	}

	@java.lang.Override
	protected void unbindImpl() {
	}

	@java.lang.Override
	public void update() {
	}

	@java.lang.Override
	public void commit() {
	}
}
