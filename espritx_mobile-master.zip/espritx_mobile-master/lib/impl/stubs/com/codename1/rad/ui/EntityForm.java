/**
 *  This package contains the foundation classes for CodeRAD views.  Nodes, Attributes, UI descriptors, etc..
 */
package com.codename1.rad.ui;


/**
 *  A form with an embedded {@link EntityEditor}.
 *  @author shannah
 */
public class EntityForm extends com.codename1.ui.Form {

	public EntityForm(com.codename1.rad.models.Entity entity, UI uiDescriptor) {
	}
}
