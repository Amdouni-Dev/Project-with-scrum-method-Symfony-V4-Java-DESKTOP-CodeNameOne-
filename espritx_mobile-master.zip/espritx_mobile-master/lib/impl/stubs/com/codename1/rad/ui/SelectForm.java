/**
 *  This package contains the foundation classes for CodeRAD views.  Nodes, Attributes, UI descriptors, etc..
 */
package com.codename1.rad.ui;


/**
 * 
 *  @author shannah
 */
public class SelectForm extends com.codename1.ui.Container {

	public SelectForm(com.codename1.rad.models.Entity entity, com.codename1.rad.nodes.FieldNode field) {
	}
}
