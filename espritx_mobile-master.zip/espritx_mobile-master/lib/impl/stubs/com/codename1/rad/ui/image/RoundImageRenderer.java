/**
 *  This class contains subclasses of AsyncImage
 */
package com.codename1.rad.ui.image;


/**
 * 
 *  @author shannah
 */
public class RoundImageRenderer implements PropertyImageRenderer {

	public RoundImageRenderer(int size) {
	}

	@java.lang.Override
	public com.codename1.ui.Image createImage(com.codename1.rad.models.PropertySelector selector) {
	}
}
