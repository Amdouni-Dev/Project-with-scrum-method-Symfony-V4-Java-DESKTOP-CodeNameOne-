/**
 *  This class contains subclasses of AsyncImage
 */
package com.codename1.rad.ui.image;


/**
 * 
 *  @author shannah
 */
public class RoundRectImageRenderer implements PropertyImageRenderer {

	public RoundRectImageRenderer(int width, int height, float cornerRadiusMM) {
	}

	@java.lang.Override
	public com.codename1.ui.Image createImage(com.codename1.rad.models.PropertySelector selector) {
	}
}
