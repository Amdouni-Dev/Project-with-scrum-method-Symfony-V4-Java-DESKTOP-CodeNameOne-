/**
 *  This class contains menu components that can be bound to Actions and Action lists.
 */
package com.codename1.rad.ui.menus;


/**
 * 
 *  @author shannah
 */
public class ActionSheet extends com.codename1.ui.Sheet {

	public ActionSheet(com.codename1.ui.Sheet parent, com.codename1.rad.models.Entity entity, com.codename1.rad.ui.Actions actions) {
	}
}
