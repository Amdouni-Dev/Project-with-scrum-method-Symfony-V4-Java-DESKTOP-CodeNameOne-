package com.wefeel.QRMaker;


/**
 *  This is a demo class to help you get started building a library
 * 
 *  @author Your name here
 */
public class QRMaker {

	public QRMaker() {
	}

	/**
	 *  Create a QR code image from given String
	 */
	public static com.codename1.ui.Image QRCode(String s) {
	}
}
